# pylint: disable-all
"""disable-all is usable as an inline option"""

# no warning should be issued
try:
    import this
except:
    pass
