"""pylint doesn't see the NameError in this module"""

__revision__ = None

MSG = "hello %s" % MSG

MSG2 = ("hello %s" %
        MSG2)
